package com.example.An_Yang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnYangApplicationTests {

	@Test
	void contextLoads() {
	}

}
